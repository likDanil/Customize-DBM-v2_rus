function iniciarautosave() {
  let customizesalvar = document.getElementById("customizesalvar");
  if (customizesalvar.value == 0) {
    autosavec = setInterval(saveatukak, 15000);
    document.querySelector("[name='saveatual']").innerText = 'Никогда';
  }
  if (customizesalvar.value == 1) {
    autosavec = setInterval(saveProject, 30000);
    document.querySelector("[name='saveatual']").innerText = 'Каждые 30 секунд';
  } 
  if (customizesalvar.value == 2) {
    autosavec = setInterval(saveProject, 60000);
    document.querySelector("[name='saveatual']").innerText = 'Каждые 1 минуту';
  } 
  if (customizesalvar.value == 3) {
    autosavec = setInterval(saveProject, 120000);
    document.querySelector("[name='saveatual']").innerText = 'Каждые 2 минуты';
  }
  if (customizesalvar.value == 4) {
    autosavec = setInterval(saveProject, 300000);
    document.querySelector("[name='saveatual']").innerText = 'Каждые 5 минут';
  }
  if (customizesalvar.value == 5) {
    autosavec = setInterval(saveProject, 600000);
    document.querySelector("[name='saveatual']").innerText = 'Каждые 10 минут';
  }
  if (customizesalvar.value == 6) {
    autosavec = setInterval(saveProject, 900000);
    document.querySelector("[name='saveatual']").innerText = 'Каждые 15 минут';
  }
  if (customizesalvar.value == 7) {
    autosavec = setInterval(saveProject, 1800000);
    document.querySelector("[name='saveatual']").innerText = 'Каждые 30 минут';
  }
  if (customizesalvar.value == 8) {
    autosavec = setInterval(saveProject, 2700000);
    document.querySelector("[name='saveatual']").innerText = 'Каждые 45 минут';
  }
  if (customizesalvar.value == 9) {
    autosavec = setInterval(saveProject, 3600000);
    document.querySelector("[name='saveatual']").innerText = 'Каждые 60 минут';
  }
  if (customizesalvar.value == 10) {
    autosavec = setInterval(saveatukak2, 15000);
    document.querySelector("[name='saveatual']").innerText = 'Когда создавать или редактировать действие';
  }
}

function saveatukak() {
  document.querySelector("[name='saveatual']").innerText = 'Никогда';
}
function saveatukak2() {
  document.querySelector("[name='saveatual']").innerText = 'Когда создавать или редактировать действие';
}

function autosaveupaction() {
  let customizesalvar = document.getElementById("customizesalvar");
  if (customizesalvar.value == 10) {
    saveProject();
  }
}



